import { useState } from "react";

const scenarios = [
  "Normal Day",
  "Emergency",
  "Festival",
  "Heatwave",
];

export default function App() {
  const [hour, setHour] = useState("00:00");
  const [totalPower, setTotalPower] = useState("");
  const [scenario, setScenario] = useState(scenarios[0]);
  const [log, setLog] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const data = { hour, totalPower, scenario };
    setLog((l) => [`→ Sending: ${JSON.stringify(data)}`, ...l]);

    try {
      const res = await fetch("https://amiee-textbookish-nonflakily.ngrok-free.dev", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      setLog((l) => [`← Response: ${JSON.stringify(result)}`, ...l]);

      // If Unity is added later and exposed as window.unityInstance
      if (window.unityInstance && result.poweredBuildings) {
        result.poweredBuildings.forEach((b) =>
          window.unityInstance.SendMessage("GameManager", "PowerBuilding", b)
        );
      }
    } catch (err) {
      console.error(err);
      setLog((l) => [`✖ Error: ${err.message}`, ...l]);
    }
  };

  return (
    <div className="mc-root">
      <header className="mc-header">
        <div className="mc-title">
          Village of Palampur
          <img src="/assets/steve.png" alt="Steve" className="steve-img" />
        </div>
        <div className="mc-sub">Power Control — Survival UI</div>
      </header>

      <main className="mc-main">
        <section className="mc-panel mc-left">
          <h3 className="panel-title">Power Controls</h3>

          <form className="mc-form" onSubmit={handleSubmit}>
            <label className="mc-label">
              Hour:
              <input
                className="mc-input"
                type="time"
                value={hour}
                onChange={(e) => setHour(e.target.value)}
                required
              />
            </label>

            <label className="mc-label">
              Total Power:
              <input
                className="mc-input"
                type="number"
                min="0"
                placeholder="0"
                value={totalPower}
                onChange={(e) => setTotalPower(Number(e.target.value))}
                required
              />
            </label>

            <label className="mc-label">
              Scenario:
              <select
                className="mc-select"
                value={scenario}
                onChange={(e) => setScenario(e.target.value)}
              >
                {scenarios.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </label>

            <div className="mc-btn-row">
              <button className="mc-btn wood" type="submit">
                Show
              </button>

              <button
                type="button"
                className="mc-btn wood small"
                onClick={() => {
                  setHour("");
                  setTotalPower("");
                  setScenario(scenarios[0]);
                }}
              >
                Reset
              </button>
            </div>
          </form>

          <div style={{ marginTop: 24 }}>
            <div className="panel-title">Inventory</div>
            <div className="inventory-grid">
              {[
                { name: "House", count: 5 },
                { name: "Shops", count: 4 },
                { name: "Powerhouse", count: 1 },
                { name: "Hospital", count: 1 },
                { name: "Water Plant", count: 1 },
                { name: "School", count: 1 },
              ].map((item) => (
                <div key={item.name} className="inv-slot">
                  <div className="inv-item">
                    {item.name}
                  </div>
                  <button
                    className="mc-btn craft small"
                    onClick={() =>
                      setLog((l) => [`Crafted: ${item.name} toggled`, ...l])
                    }
                  >
                    {item.count}
                  </button>
                </div>
              ))}
            </div>
          </div>

        </section>

        <section className="mc-panel mc-right">
          <h3 className="panel-title">Village Map</h3>

          <div className="map-area">
            {/* Placeholder artwork / future Unity iframe */}
            <div className="map-overlay">
              <div className="map-title">Unity scene will appear here</div>
              {/* <div className="map-sub">Build WebGL and place into public/unity</div> */}
            </div>
          </div>


        </section>
      </main>

    </div>
  );
}

