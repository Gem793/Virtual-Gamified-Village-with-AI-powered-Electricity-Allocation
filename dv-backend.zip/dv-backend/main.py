from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json
import numpy as np

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class RequestData(BaseModel):
    hour: str
    totalPower: float
    scenario: str

# -------------------------------
# SCENARIO + TIME MULTIPLIERS
# -------------------------------
def scenario_factor(scenario: str, category: str):
    table = {
        "normal":      {"hospital":1.0, "school":1.0, "residential":1.0, "water_plant":1.0, "shop":1.0},
        "festival":    {"hospital":0.7, "school":0.3, "residential":1.6, "water_plant":1.7, "shop":1.6},
        "heatwave":    {"hospital":1.2, "school":0.5, "residential":1.2, "water_plant":1.8, "shop":0.8},
        "emergency":   {"hospital":2.0, "school":0.4, "residential":0.7, "water_plant":1.5, "shop":0.1}
    }
    return table.get(scenario, table["normal"]).get(category, 1.0)

def time_factor(hour: int, category: str):
    if 0 <= hour < 6:
        table = {"hospital":1.4, "school":0.3, "residential":1.1, "water_plant":1.0, "shop":0.2}
    elif 6 <= hour < 18:
        table = {"hospital":1.4, "school":1.2, "residential":1.0, "water_plant":1.1, "shop":1.3}
    else:
        table = {"hospital":1.4, "school":0.4, "residential":1.3, "water_plant":1.2, "shop":0.8}
    return table[category]

def calculate_score(b, scenario, hour):
    base = b["base_priority"]
    return round(base * scenario_factor(scenario, b["category"]) * time_factor(hour, b["category"]), 3)

# -------------------------------
# CLEAN SIMPLE ALLOCATION
# -------------------------------
@app.post("/allocate_ai")
def allocate_power_ai(request: RequestData):

    hour = int(request.hour.split(":")[0])
    scenario = request.scenario.lower().strip()
    total_power = float(request.totalPower)

    with open("buildings.json") as f:
        buildings = json.load(f)

    # 1. Calculate scores
    for b in buildings:
        b["score"] = calculate_score(b, scenario, hour)

    total_score = sum(b["score"] for b in buildings)

    # 2. First pass allocation based on score ratio
    allocations = []
    for b in buildings:
        share = (b["score"] / total_score) * total_power
        allocated = min(share, b["load"])
        allocations.append({
            "id": b["id"],
            "score": b["score"],
            "load": b["load"],
            "allocated": allocated
        })

    # 3. Check remaining and redistribute if needed
    allocated_sum = sum(a["allocated"] for a in allocations)
    remaining = total_power - allocated_sum

    if remaining > 0:
        # redistribute to buildings not at max load
        flexible = [a for a in allocations if a["allocated"] < a["load"]]

        if flexible:
            flex_scores = sum(a["score"] for a in flexible)

            for a in flexible:
                add = remaining * (a["score"] / flex_scores)
                a["allocated"] += min(add, a["load"] - a["allocated"])

    # 4. Final correction to make sure totals match exactly
    final_sum = sum(a["allocated"] for a in allocations)
    correction = total_power - final_sum
    allocations[0]["allocated"] += correction  # adjust tiny rounding difference

    # Round for output
    for a in allocations:
        a["allocated"] = round(a["allocated"], 2)

    return {
        "hour": request.hour,
        "scenario": scenario,
        "total_power": total_power,
        "total_allocated_final": round(sum(a["allocated"] for a in allocations), 2),
        "allocations": allocations
    }













